install.packages("twitteR","RCurl","RJSONIO","stringr","tm","wordcloud")
library(twitteR)
library(RCurl)
library(RJSONIO)
library(stringr)
library(tm)
library(wordcloud)

#verfiyng the twitter API
my_key='FjiY50ykoC733CK5Pxx0P8gNV'
my_secret = 'NrYYEyVewnfVGr4E8l9IVtxaaelg01Uhcl0xrEmMmFZORoP0VJ'
atoken = '140774778-BILNH5b1VPSTjs4ufJM0uMFAoE34KkA4pNplYjTu'
asecret = 'VSWBhB2MpRQw5zbl4G9JlbyYFgQ8aPS0Ygrl9sOvo9eOQ'

options(httr_oauth_cache=T)

setup_twitter_oauth(my_key, my_secret,atoken,asecret)
getSentiment <- function (text, key){
  text <- URLencode(text);  
  #save all the spaces, then get rid of the weird characters that break the API, then convert back the URL-encoded spaces.
  text <- str_replace_all(text, "%20", " ");
  text <- str_replace_all(text, "%\\d\\d", "");
  text <- str_replace_all(text, " ", "%20");
  
  if (str_length(text) > 360){
    text <- substr(text, 0, 359);
  }
  ##########################################
  data <- getURL(paste("http://api.datumbox.com/1.0/TwitterSentimentAnalysis.json?api_key=", key, "&text=",text, sep=""))
  
  js <- fromJSON(data, asText=TRUE);
  
  sentiment = js$output$result
  
  
  return(list(sentiment=sentiment))
  
}
#The clean.text() function

clean.text <- function(some_txt)
{
  some_txt = gsub("(RT|via)((?:\\b\\W*@\\w+)+)", "", some_txt)
  some_txt = gsub("@\\w+", "", some_txt)
  some_txt = gsub("[[:punct:]]", "", some_txt)
  some_txt = gsub("[[:digit:]]", "", some_txt)
  some_txt = gsub("http\\w+", "", some_txt)
  some_txt = gsub("[ \t]{2,}", "", some_txt)
  some_txt = gsub("^\\s+|\\s+$", "", some_txt)
  
  # define "tolower error handling" function
  try.tolower = function(x)
  {
    y = NA
    try_error = tryCatch(tolower(x), error=function(e) e)
    if (!inherits(try_error, "error"))
      y = tolower(x)
    return(y)
  }
  
  some_txt = sapply(some_txt, try.tolower)
  some_txt = some_txt[some_txt != ""]
  names(some_txt) = NULL
  return(some_txt)
}

# harvest tweets
tweets = searchTwitter("@iowadot", n=1499, lang="en")
#d = twListToDF(tweets)
#d
#d$text
#str(d)
#View(d)


tweet_txt = sapply(tweets, function(x) x$getText())
tweet_clean = clean.text(tweet_txt)
tweet_num = length(tweet_clean)
tweet_df = data.frame(text=tweet_clean, sentiment=rep("", tweet_num), stringsAsFactors=FALSE)
sentiment = rep(0, tweet_num)
for (i in 1:tweet_num)
{
  tmp = getSentiment(tweet_clean[i], "b34bf514405eee1f46e7b752dec3b108")
  
  tweet_df$sentiment[i] = tmp$sentiment
  
  print(paste(i," of ", tweet_num))
  
}

# delete rows with no sentiment
tweet_df <- tweet_df[tweet_df$sentiment!="",]
sents = levels(factor(tweet_df$sentiment))
tweet_df
#d = twListToDF(d = twListToDF(tw))
View(tweet_df)

# saving the file in csv
write.table(tweet_df,file=Analysis1.csv,sep=",",row.names=F)
